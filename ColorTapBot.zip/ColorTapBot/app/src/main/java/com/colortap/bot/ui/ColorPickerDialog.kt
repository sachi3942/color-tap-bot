package com.colortap.bot.ui

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import com.colortap.bot.R

/** Minimal, dependency-free RGB color picker with quick presets. */
class ColorPickerDialog(
    context: Context,
    initialColor: Int = Color.YELLOW,
    private val onPicked: (Int) -> Unit
) : Dialog(context) {

    private val presets = listOf(
        "Yellow" to Color.parseColor("#FFD400"),
        "Red" to Color.parseColor("#FF3B30"),
        "Green" to Color.parseColor("#34C759"),
        "Blue" to Color.parseColor("#0A84FF"),
        "White" to Color.WHITE,
        "Black" to Color.BLACK,
        "Purple" to Color.parseColor("#AF52DE"),
        "Orange" to Color.parseColor("#FF9500")
    )

    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        super.onCreate(savedInstanceState)
        val view = LayoutInflater.from(context).inflate(R.layout.dialog_color_picker, null)
        setContentView(view)
        window?.setBackgroundDrawableResource(android.R.color.transparent)

        val preview = view.findViewById<View>(R.id.preview)
        val seekR = view.findViewById<SeekBar>(R.id.seekR)
        val seekG = view.findViewById<SeekBar>(R.id.seekG)
        val seekB = view.findViewById<SeekBar>(R.id.seekB)
        val tvR = view.findViewById<TextView>(R.id.tvR)
        val tvG = view.findViewById<TextView>(R.id.tvG)
        val tvB = view.findViewById<TextView>(R.id.tvB)

        var current = initialColor

        fun update() {
            preview.setBackgroundColor(current)
            tvR.text = Color.red(current).toString()
            tvG.text = Color.green(current).toString()
            tvB.text = Color.blue(current).toString()
        }

        seekR.progress = Color.red(initialColor)
        seekG.progress = Color.green(initialColor)
        seekB.progress = Color.blue(initialColor)
        update()

        val listener = { _: SeekBar?, _: Int, _: Boolean ->
            current = Color.rgb(seekR.progress, seekG.progress, seekB.progress)
            update()
        }
        val simple = object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) { listener(sb, p, fromUser) }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        }
        seekR.setOnSeekBarChangeListener(simple)
        seekG.setOnSeekBarChangeListener(simple)
        seekB.setOnSeekBarChangeListener(simple)

        val presetRow = view.findViewById<LinearLayout>(R.id.presetRow)
        presets.forEach { (_, color) ->
            val dot = View(context)
            val size = (34 * context.resources.displayMetrics.density).toInt()
            val lp = LinearLayout.LayoutParams(size, size)
            lp.marginEnd = (8 * context.resources.displayMetrics.density).toInt()
            dot.layoutParams = lp
            val bg = android.graphics.drawable.GradientDrawable()
            bg.shape = android.graphics.drawable.GradientDrawable.OVAL
            bg.setColor(color)
            bg.setStroke(2, Color.parseColor("#2E3358"))
            dot.background = bg
            dot.setOnClickListener {
                current = color
                seekR.progress = Color.red(color)
                seekG.progress = Color.green(color)
                seekB.progress = Color.blue(color)
                update()
            }
            presetRow.addView(dot)
        }

        view.findViewById<View>(R.id.btnCancel).setOnClickListener { dismiss() }
        view.findViewById<View>(R.id.btnConfirm).setOnClickListener {
            onPicked(current)
            dismiss()
        }
    }
}
