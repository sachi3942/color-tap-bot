# ColorTap Bot 🎯

ඔබ තෝරන පාට screen එකේ දිගටම (consecutive) කියන වාර ගාණකට පස්සේ, ඔබ දක්වන ස්ථානයේ auto-tap කරන Android ඇප් එකක්. සම්පූර්ණයෙන්ම configure කරගත හැකි "escalation" logic එකක් සමග (yellow/blue continue → next round 2x tap, white → reset).

## 📱 APK එක හදාගන්නේ කොහොමද (GitHub Actions – ලේසිම විදිහ)

1. **GitHub** ගිණුමකට log වෙන්න → **New repository** එකක් හදන්න (public හෝ private, ඕන එකක්).
2. මේ zip file එක **extract** කරන්න (ඔබේ පරිගණකයේ).
3. Repository එකේ **"Add file" → "Upload files"** එබලා, extract කරපු ෆෝල්ඩරයේ ඇතුළත තියෙන සියලුම files/folders (README එකත් සමගම) drag කරලා දාන්න. (ෆෝල්ඩරය නෙවෙයි, ඇතුළත තියෙන දේවල් උඩ දාන්න ඕන — `app/`, `.github/`, `build.gradle`, ආදිය root එකේම වෙන්න ඕන).
4. **Commit changes** කරන්න (branch: `main`).
5. ඉහළ **"Actions"** tab එකට යන්න → `Build APK` කියන workflow එක automatically run වෙනවා (green tick එකක් වෙනකම් 3-5 විනාඩි ඉන්න).
6. Run එක success උනාට පස්සේ, ඒ run එක click කරලා pageඑකේ පහළින් **Artifacts** කියන කොටසේ `ColorTapBot-debug-apk` කියලා zip එකක් download කරගන්න.
7. ඒ zip එක ඇතුළේ `app-debug.apk` file එක ඔබේ ෆෝන් එකට copy කරලා install කරගන්න (Unknown sources / Install unknown apps allow කරන්න ඕන වෙයි).

> Workflow එක යළි run කරගන්න ඕන නම් **Actions → Build APK → Run workflow** button එකෙන්ම manual ව run කරගන්නත් පුළුවන්.

## ⚙️ App එක setup කරගන්නේ කොහොමද

ඇප් එක open කළාට පස්සේ:

1. **Permissions** කාඩ් එකේ තියෙන 3 items grant කරන්න:
   - **Accessibility service** – auto-tap කරන්න ඕන (Settings → Accessibility → ColorTap Bot → On)
   - **Overlay permission** – screen එක උඩින් pointer තියන්න ඕන
   - **Screen capture** – "Start" කරද්දි system එකෙන් අහන permission එකක් (Master switch එකෙන් auto ask කරයි)

2. **"+ Add Rule"** එබලා rule එකක් හදන්න:
   - **Name** – rule එකට නමක්
   - **Target colors** – ඔබ count කරන්න ඕන පාට් (+ button එකෙන් කීපයක්ම දාන්න පුළුවන් — ඔබේ උදාහරණයේ කහ + නිල් දෙකම මෙතන දාන්න)
   - **Reset color** – මේ පාට ආවොත් ගණන ආයෙත් 0 ට යනවා (උදා: සුදු)
   - **Detection point** – "📍 Pick on screen" එබලා, target app එකට ගිහින් පාට එන තැන draggable මාක් එක තියලා **Set** එබන්න
   - **Tap point** – ඒ විදිහටම, tap වෙන්න ඕන තැන set කරන්න
   - **Consecutive occurrences needed** – කී වතාවක් දිගටම ආවට tap වෙන්න ඕන ද (උදා: 10)
   - **Normal tap count** – සාමාන්‍ය trigger එකකදී tap කීයක් (1)
   - **Escalated tap count** – reset නොවී ආයෙත් target color එකක්ම ආවොත්, ඊළඟ trigger එකේදී tap කීයක් (2)
   - **Gap between taps (ms)** – tap කිහිපයක් අතර කාලය
   - **Color match tolerance** – screen එකේ pixel color එක exact නොවුනත් match වෙන්න ඉඩ දෙන range එක

3. Rules කීපයක්ම එකවර දාන්න පුළුවන් (item එකක් pointer කීපයක් = rules කීපයක්).

4. **Master switch** එබලා automation එක start කරන්න. Notification එකේ **Stop** button එකෙන් ඕනෑම වෙලාවක නවත්තන්න පුළුවන්.

## 🧠 Logic එක සාරාංශයක් (default උදාහරණය අනුව)

- කහ (target) දිගටම 10 වතාවක් ආවොත් → tap point එකේ 1 වතාවක් tap වෙනවා.
- ඒ 10 සම්පූර්ණ වෙද්දි නිල් (තව target color එකක්) ආවත් කහ කියලම ගණන් ගන්නවා.
- 10 පිරිලා tap උනාට පස්සේ ඊළඟට එන පාට:
  - **සුදු (reset color)** → සම්පූර්ණයෙන්ම reset, ආයෙත් 0 ඉඳන් ගණන් පටන් ගන්නවා.
  - **කහ/නිල් (target)** → ඊළඟ වතාවේ 10 පිරෙනකොට tap **2 වතාවක්** වෙනවා (escalated).
  - වෙන පාටක් → සාමාන්‍ය විදිහටම දිගටම ගණන් ගනිමින් යනවා.
- Escalated tap (2x) එක fire උනාට පස්සේ, ඊළඟට මොනවා ආවත් ආයෙත් tap වෙන්නෙ නෑ — loop එක clean ව මුල ඉඳන් නැවත පටන් ගන්නවා.

මේ ගණන් (10), tap ගණන් (1/2), පාට් සහ ms delay ඔක්කොම rule editor එකෙන් ඔබට ඕන විදිහට වෙනස් කරගන්න පුළුවන්.

## 🔒 සටහන්

- මේක accessibility service එකක් හරහා tap dispatch කරන නිසා, සමහර ඇප්ස් (specially anti-cheat තියෙන games) වල ක්‍රියා නොකරන්න පුළුවන්.
- Screen capture permission එක app එක restart කරන හැම වතාවෙම යළි ඉල්ලනවා (Android security restriction එකක්, source code එකෙන් change කරන්න බැරි දෙයක්).
- Rules සියල්ල ඔබේ ෆෝන් එකේම (SharedPreferences) save වෙනවා — internet අවශ්‍ය නෑ app එක run කරන්න.

## 🛠 Local build (optional, Android Studio තියෙනවා නම්)

`ColorTapBot` ෆෝල්ඩරය Android Studio වලින් **Open** කරලා, Gradle sync වෙනකම් ඉඳලා, **Run** කරන්න හෝ **Build → Build Bundle(s)/APK(s) → Build APK(s)** කරන්න.
