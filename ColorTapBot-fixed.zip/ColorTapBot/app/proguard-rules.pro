# Keep everything for now, this is a utility automation app
-dontwarn **
