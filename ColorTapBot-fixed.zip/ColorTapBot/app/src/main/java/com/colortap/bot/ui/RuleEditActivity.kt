package com.colortap.bot.ui

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.colortap.bot.R
import com.colortap.bot.model.Rule
import com.colortap.bot.service.PointPickerOverlayService
import com.colortap.bot.util.PrefsManager

class RuleEditActivity : AppCompatActivity() {

    private lateinit var rule: Rule
    private lateinit var rules: MutableList<Rule>

    private lateinit var rowTargetColors: LinearLayout
    private lateinit var swatchReset: View
    private lateinit var tvDetectPoint: TextView
    private lateinit var tvTapPoint: TextView

    private lateinit var stepperRequired: Stepper
    private lateinit var stepperNormalTaps: Stepper
    private lateinit var stepperEscalatedTaps: Stepper
    private lateinit var stepperTapInterval: Stepper

    private var pickingMode: String? = null

    private val pointReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val x = intent?.getIntExtra("x", -1) ?: -1
            val y = intent?.getIntExtra("y", -1) ?: -1
            val mode = intent?.getStringExtra("mode") ?: return
            if (mode == "detect") {
                rule.detectX = x; rule.detectY = y
                tvDetectPoint.text = "x=$x, y=$y"
            } else {
                rule.tapX = x; rule.tapY = y
                tvTapPoint.text = "x=$x, y=$y"
            }
            pickingMode = null
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_rule_edit)

        rules = PrefsManager.loadRules(this)
        val ruleId = intent.getStringExtra("ruleId")
        rule = rules.find { it.id == ruleId } ?: Rule().also { rules.add(it) }

        findViewById<EditText>(R.id.etName).setText(rule.name)
        rowTargetColors = findViewById(R.id.rowTargetColors)
        swatchReset = findViewById(R.id.swatchReset)
        tvDetectPoint = findViewById(R.id.tvDetectPoint)
        tvTapPoint = findViewById(R.id.tvTapPoint)

        renderTargetColors()
        renderResetSwatch()
        renderPoints()

        stepperRequired = Stepper(findViewById(R.id.stepperRequired), rule.requiredCount.toLong(), 1, 999, 1) {}
        stepperNormalTaps = Stepper(findViewById(R.id.stepperNormalTaps), rule.normalTapCount.toLong(), 1, 20, 1) {}
        stepperEscalatedTaps = Stepper(findViewById(R.id.stepperEscalatedTaps), rule.escalatedTapCount.toLong(), 1, 20, 1) {}
        stepperTapInterval = Stepper(findViewById(R.id.stepperTapInterval), rule.tapIntervalMs, 20, 3000, 20) {}

        val seekTolerance = findViewById<SeekBar>(R.id.seekTolerance)
        val tvTolerance = findViewById<TextView>(R.id.tvTolerance)
        seekTolerance.progress = rule.tolerance
        tvTolerance.text = rule.tolerance.toString()
        seekTolerance.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) { tvTolerance.text = p.toString() }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }

        findViewById<View>(R.id.btnPickDetect).setOnClickListener { startPicking("detect") }
        findViewById<View>(R.id.btnPickTap).setOnClickListener { startPicking("tap") }
        findViewById<View>(R.id.btnPickReset).setOnClickListener {
            ColorPickerDialog(this, rule.resetColor ?: Color.WHITE) { c ->
                rule.resetColor = c; renderResetSwatch()
            }.show()
        }
        findViewById<View>(R.id.btnClearReset).setOnClickListener {
            rule.resetColor = null; renderResetSwatch()
        }

        findViewById<View>(R.id.btnSave).setOnClickListener { save(seekTolerance.progress) }

        LocalBroadcastManager.getInstance(this)
            .registerReceiver(pointReceiver, IntentFilter(PointPickerOverlayService.ACTION_POINT_PICKED))
    }

    override fun onDestroy() {
        LocalBroadcastManager.getInstance(this).unregisterReceiver(pointReceiver)
        super.onDestroy()
    }

    private fun startPicking(mode: String) {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Overlay permission එක මුලින්ම දෙන්න", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        pickingMode = mode
        Toast.makeText(this, "ඕනෑම app එකකට ගිහින් තිත draggable මාක් එක තියන්න, පස්සේ Set එබන්න", Toast.LENGTH_LONG).show()
        val i = Intent(this, PointPickerOverlayService::class.java)
        i.putExtra(PointPickerOverlayService.EXTRA_MODE, mode)
        i.putExtra(PointPickerOverlayService.EXTRA_RULE_ID, rule.id)
        startService(i)
    }

    private fun renderTargetColors() {
        rowTargetColors.removeAllViews()
        rule.targetColors.forEachIndexed { index, color ->
            rowTargetColors.addView(makeSwatch(color, removable = true) {
                rule.targetColors.removeAt(index)
                renderTargetColors()
            })
        }
        rowTargetColors.addView(makeAddButton {
            ColorPickerDialog(this, Color.YELLOW) { c ->
                rule.targetColors.add(c)
                renderTargetColors()
            }.show()
        })
    }

    private fun makeSwatch(color: Int, removable: Boolean, onClick: () -> Unit): View {
        val size = (40 * resources.displayMetrics.density).toInt()
        val v = View(this)
        val lp = LinearLayout.LayoutParams(size, size)
        lp.marginEnd = (10 * resources.displayMetrics.density).toInt()
        v.layoutParams = lp
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(color)
        bg.setStroke(3, Color.parseColor(if (removable) "#FF6B6B" else "#2E3358"))
        v.background = bg
        v.setOnClickListener { onClick() }
        return v
    }

    private fun makeAddButton(onClick: () -> Unit): View {
        val size = (40 * resources.displayMetrics.density).toInt()
        val tv = TextView(this)
        tv.layoutParams = LinearLayout.LayoutParams(size, size)
        tv.text = "+"
        tv.gravity = android.view.Gravity.CENTER
        tv.textSize = 18f
        tv.setTextColor(Color.WHITE)
        tv.background = androidx.core.content.ContextCompat.getDrawable(this, R.drawable.bg_pill_accent)
        tv.setOnClickListener { onClick() }
        return tv
    }

    private fun renderResetSwatch() {
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(rule.resetColor ?: Color.parseColor("#00000000"))
        bg.setStroke(2, Color.parseColor("#2E3358"))
        swatchReset.background = bg
    }

    private fun renderPoints() {
        tvDetectPoint.text = if (rule.detectX >= 0) "x=${rule.detectX}, y=${rule.detectY}" else "Not set"
        tvTapPoint.text = if (rule.tapX >= 0) "x=${rule.tapX}, y=${rule.tapY}" else "Not set"
    }

    private fun save(tolerance: Int) {
        rule.name = findViewById<EditText>(R.id.etName).text.toString().ifBlank { "Rule" }
        rule.requiredCount = stepperRequired.get().toInt()
        rule.normalTapCount = stepperNormalTaps.get().toInt()
        rule.escalatedTapCount = stepperEscalatedTaps.get().toInt()
        rule.tapIntervalMs = stepperTapInterval.get()
        rule.tolerance = tolerance

        if (rule.targetColors.isEmpty()) {
            Toast.makeText(this, "අඩුම තරමින් target color එකක් එකතු කරන්න", Toast.LENGTH_SHORT).show()
            return
        }
        if (rule.detectX < 0 || rule.tapX < 0) {
            Toast.makeText(this, "Detection point සහ Tap point දෙකම set කරන්න", Toast.LENGTH_SHORT).show()
            return
        }

        if (rules.none { it.id == rule.id }) rules.add(rule)
        PrefsManager.saveRules(this, rules)
        Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
        finish()
    }
}
