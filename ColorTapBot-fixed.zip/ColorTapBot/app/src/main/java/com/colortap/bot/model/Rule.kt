package com.colortap.bot.model

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * A single automation rule:
 *  - watches a point on screen (detectX, detectY)
 *  - counts consecutive matches of [targetColors] (any color in the list counts the same)
 *  - if [resetColor] appears, the running count is cleared back to zero
 *  - once the count reaches [requiredCount], a tap (or several taps) is fired at (tapX, tapY)
 *  - the color read *immediately after* a trigger decides what happens next:
 *      * resetColor            -> full reset, back to normal mode
 *      * one of targetColors   -> "armed" - the NEXT time the threshold is reached the tap
 *                                 fires [escalatedTapCount] times instead of [normalTapCount]alt,
 *                                 then automatically falls back to normal mode
 *      * anything else         -> normal mode continues, nothing special happens
 */
data class Rule(
    var id: String = UUID.randomUUID().toString(),
    var name: String = "New Rule",
    var enabled: Boolean = true,

    var detectX: Int = -1,
    var detectY: Int = -1,

    var targetColors: MutableList<Int> = mutableListOf(),
    var resetColor: Int? = null,
    var tolerance: Int = 28,

    var requiredCount: Int = 10,

    var tapX: Int = -1,
    var tapY: Int = -1,
    var normalTapCount: Int = 1,
    var escalatedTapCount: Int = 2,
    var tapIntervalMs: Long = 120,

    var sampleIntervalMs: Long = 150
) {
    fun toJson(): JSONObject {
        val o = JSONObject()
        o.put("id", id)
        o.put("name", name)
        o.put("enabled", enabled)
        o.put("detectX", detectX)
        o.put("detectY", detectY)
        val arr = JSONArray()
        targetColors.forEach { arr.put(it) }
        o.put("targetColors", arr)
        o.put("resetColor", resetColor ?: JSONObject.NULL)
        o.put("tolerance", tolerance)
        o.put("requiredCount", requiredCount)
        o.put("tapX", tapX)
        o.put("tapY", tapY)
        o.put("normalTapCount", normalTapCount)
        o.put("escalatedTapCount", escalatedTapCount)
        o.put("tapIntervalMs", tapIntervalMs)
        o.put("sampleIntervalMs", sampleIntervalMs)
        return o
    }

    companion object {
        fun fromJson(o: JSONObject): Rule {
            val r = Rule()
            r.id = o.optString("id", UUID.randomUUID().toString())
            r.name = o.optString("name", "Rule")
            r.enabled = o.optBoolean("enabled", true)
            r.detectX = o.optInt("detectX", -1)
            r.detectY = o.optInt("detectY", -1)
            val arr = o.optJSONArray("targetColors")
            val list = mutableListOf<Int>()
            if (arr != null) for (i in 0 until arr.length()) list.add(arr.getInt(i))
            r.targetColors = list
            r.resetColor = if (o.isNull("resetColor")) null else o.optInt("resetColor")
            r.tolerance = o.optInt("tolerance", 28)
            r.requiredCount = o.optInt("requiredCount", 10)
            r.tapX = o.optInt("tapX", -1)
            r.tapY = o.optInt("tapY", -1)
            r.normalTapCount = o.optInt("normalTapCount", 1)
            r.escalatedTapCount = o.optInt("escalatedTapCount", 2)
            r.tapIntervalMs = o.optLong("tapIntervalMs", 120)
            r.sampleIntervalMs = o.optLong("sampleIntervalMs", 150)
            return r
        }
    }
}
