package com.colortap.bot.model

import kotlin.math.abs

/** Result of feeding one sampled color into a rule's state machine. */
data class TapAction(val ruleId: String, val x: Int, val y: Int, val tapCount: Int, val intervalMs: Long)

private enum class Phase { NORMAL, AFTER_TRIGGER }

/** Runtime (non-persisted) state for a single rule. */
class RuleState(val rule: Rule) {
    private var phase = Phase.NORMAL
    private var consecutive = 0
    private var doubleArmed = false

    var lastMatched: String = "-"
        private set
    var progressText: String = "0 / ${rule.requiredCount}"
        private set
    var totalTaps: Int = 0
        private set

    fun reset() {
        phase = Phase.NORMAL
        consecutive = 0
        doubleArmed = false
        progressText = "0 / ${rule.requiredCount}"
    }

    /** Feed a freshly sampled color. Returns a TapAction if a tap should fire. */
    fun onColorSampled(color: Int): TapAction? {
        val isTarget = rule.targetColors.any { colorsMatch(it, color, rule.tolerance) }
        val isReset = rule.resetColor?.let { colorsMatch(it, color, rule.tolerance) } ?: false

        var action: TapAction? = null

        when (phase) {
            Phase.NORMAL -> {
                if (isTarget) {
                    consecutive++
                    lastMatched = "target"
                    if (consecutive >= rule.requiredCount) {
                        val taps = if (doubleArmed) rule.escalatedTapCount else rule.normalTapCount
                        action = TapAction(rule.id, rule.tapX, rule.tapY, taps, rule.tapIntervalMs)
                        totalTaps += taps
                        if (doubleArmed) {
                            // escalated round just fired -> always fall back to a clean normal run
                            doubleArmed = false
                            consecutive = 0
                            phase = Phase.NORMAL
                        } else {
                            consecutive = 0
                            phase = Phase.AFTER_TRIGGER
                        }
                    }
                } else if (isReset) {
                    lastMatched = "reset"
                    consecutive = 0
                }
                // any other color: ignored, counter untouched
            }
            Phase.AFTER_TRIGGER -> {
                when {
                    isReset -> {
                        lastMatched = "reset"
                        consecutive = 0
                        doubleArmed = false
                        phase = Phase.NORMAL
                    }
                    isTarget -> {
                        lastMatched = "target (armed x${rule.escalatedTapCount})"
                        doubleArmed = true
                        consecutive = 1
                        phase = Phase.NORMAL
                    }
                    else -> {
                        lastMatched = "other"
                        consecutive = 0
                        doubleArmed = false
                        phase = Phase.NORMAL
                    }
                }
            }
        }

        progressText = "$consecutive / ${rule.requiredCount}" + if (doubleArmed) " (x${rule.escalatedTapCount} armed)" else ""
        return action
    }
}

fun colorsMatch(a: Int, b: Int, tolerance: Int): Boolean {
    val ar = (a shr 16) and 0xFF; val ag = (a shr 8) and 0xFF; val ab = a and 0xFF
    val br = (b shr 16) and 0xFF; val bg = (b shr 8) and 0xFF; val bb = b and 0xFF
    return abs(ar - br) <= tolerance && abs(ag - bg) <= tolerance && abs(ab - bb) <= tolerance
}
