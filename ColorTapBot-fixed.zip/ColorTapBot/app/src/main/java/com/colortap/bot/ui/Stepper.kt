package com.colortap.bot.ui

import android.view.View
import android.widget.TextView
import com.colortap.bot.R

/** Wires a `row_stepper` include to an Int/Long value with min/max/step bounds. */
class Stepper(
    root: View,
    private var value: Long,
    private val min: Long,
    private val max: Long,
    private val step: Long,
    private val onChange: (Long) -> Unit
) {
    private val tvValue: TextView = root.findViewById(R.id.tvValue)
    private val btnMinus: TextView = root.findViewById(R.id.btnMinus)
    private val btnPlus: TextView = root.findViewById(R.id.btnPlus)

    init {
        render()
        btnMinus.setOnClickListener {
            value = (value - step).coerceAtLeast(min)
            render(); onChange(value)
        }
        btnPlus.setOnClickListener {
            value = (value + step).coerceAtMost(max)
            render(); onChange(value)
        }
    }

    private fun render() { tvValue.text = value.toString() }

    fun get(): Long = value
}
