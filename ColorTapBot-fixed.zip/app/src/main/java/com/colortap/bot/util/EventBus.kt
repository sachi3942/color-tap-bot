package com.colortap.bot.util

import android.os.Handler
import android.os.Looper

/** Simple main-thread event bus so the service can push live log lines / running state to the UI. */
object EventBus {
    private val handler = Handler(Looper.getMainLooper())
    private val listeners = mutableListOf<(String) -> Unit>()
    private val stateListeners = mutableListOf<(Boolean) -> Unit>()

    @Volatile var isRunning: Boolean = false
        private set

    fun addLogListener(l: (String) -> Unit) { listeners.add(l) }
    fun removeLogListener(l: (String) -> Unit) { listeners.remove(l) }

    fun addStateListener(l: (Boolean) -> Unit) { stateListeners.add(l) }
    fun removeStateListener(l: (Boolean) -> Unit) { stateListeners.remove(l) }

    fun log(msg: String) {
        handler.post { listeners.forEach { it(msg) } }
    }

    fun setRunning(running: Boolean) {
        isRunning = running
        handler.post { stateListeners.forEach { it(running) } }
    }
}
