package com.colortap.bot.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.util.DisplayMetrics
import androidx.core.app.NotificationCompat
import com.colortap.bot.R
import com.colortap.bot.model.Rule
import com.colortap.bot.model.RuleState
import com.colortap.bot.ui.MainActivity
import com.colortap.bot.util.EventBus
import com.colortap.bot.util.PrefsManager

class ScreenCaptureService : Service() {

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var handler: Handler? = null

    private val ruleStates = mutableMapOf<String, RuleState>()
    private var running = false

    override fun onCreate() {
        super.onCreate()
        EventBus.log("ScreenCaptureService.onCreate")
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                androidx.core.app.ServiceCompat.startForeground(
                    this, NOTIF_ID, buildNotification(),
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                )
            } else {
                startForeground(NOTIF_ID, buildNotification())
            }
        } catch (t: Throwable) {
            reportFailure("startForeground failed", t)
            stopSelf()
        }
    }

    private fun reportFailure(context: String, e: Throwable) {
        val msg = "$context: ${e.javaClass.simpleName}: ${e.message}"
        EventBus.log(msg)
        Handler(mainLooper).post {
            android.widget.Toast.makeText(applicationContext, msg, android.widget.Toast.LENGTH_LONG).show()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        EventBus.log("onStartCommand action=${intent?.action}")
        if (intent?.action == ACTION_STOP) {
            stopCapture()
            return START_NOT_STICKY
        }
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, -1) ?: -1
        val data = intent?.getParcelableExtra<Intent>(EXTRA_DATA)
        if (data != null && resultCode != -1) {
            startCapture(resultCode, data)
        }
        return START_STICKY
    }

    private fun buildNotification(): Notification {
        val channelId = "colortap_capture"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val mgr = getSystemService(NotificationManager::class.java)
            if (mgr.getNotificationChannel(channelId) == null) {
                mgr.createNotificationChannel(
                    NotificationChannel(channelId, "ColorTap Bot", NotificationManager.IMPORTANCE_LOW)
                )
            }
        }
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopIntent = PendingIntent.getService(
            this, 0, Intent(this, ScreenCaptureService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("ColorTap Bot ක්‍රියාත්මකයි")
            .setContentText("Color detection running in background")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(openIntent)
            .addAction(0, "Stop", stopIntent)
            .setOngoing(true)
            .build()
    }

    private fun startCapture(resultCode: Int, data: Intent) {
        if (running) return
        try {
            startCaptureInternal(resultCode, data)
        } catch (t: Throwable) {
            reportFailure("Screen capture failed to start", t)
            EventBus.setRunning(false)
            stopSelf()
        }
    }

    private fun startCaptureInternal(resultCode: Int, data: Intent) {
        EventBus.log("step 1/6: requesting MediaProjection from token")
        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = mgr.getMediaProjection(resultCode, data)
        if (mediaProjection == null) {
            // Grant token wasn't valid (e.g. stale/expired, or process was killed between the
            // system dialog and this call) - fail loudly instead of silently sitting idle.
            val msg = "MediaProjection token invalid - please grant screen capture again"
            EventBus.log(msg)
            Handler(mainLooper).post { android.widget.Toast.makeText(applicationContext, msg, android.widget.Toast.LENGTH_LONG).show() }
            EventBus.setRunning(false)
            stopSelf()
            return
        }

        EventBus.log("step 2/6: MediaProjection obtained, registering callback")
        // Android 14+ (API 34) requires a registered callback BEFORE createVirtualDisplay(),
        // otherwise the projection silently fails / throws IllegalStateException.
        mediaProjection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                val msg = "MediaProjection stopped by system (revoked/expired/killed)"
                EventBus.log(msg)
                Handler(mainLooper).post { android.widget.Toast.makeText(applicationContext, msg, android.widget.Toast.LENGTH_LONG).show() }
                stopCapture()
            }
        }, Handler(mainLooper))

        EventBus.log("step 3/6: reading display metrics")
        val metrics = DisplayMetrics()
        // WindowManager.defaultDisplay throws UnsupportedOperationException when called from a
        // Service (a non-visual Context) on API 30+. DisplayManager has no such restriction.
        val dm = getSystemService(Context.DISPLAY_SERVICE) as android.hardware.display.DisplayManager
        val display = dm.getDisplay(android.view.Display.DEFAULT_DISPLAY)
        @Suppress("DEPRECATION")
        display.getRealMetrics(metrics)
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val density = metrics.densityDpi
        EventBus.log("step 4/6: metrics ${width}x${height}@${density}dpi, creating ImageReader")

        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        EventBus.log("step 5/6: creating VirtualDisplay")
        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "ColorTapCapture", width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface, null, null
        )
        if (virtualDisplay == null) {
            EventBus.log("step 5/6 FAILED: createVirtualDisplay returned null")
        } else {
            EventBus.log("step 6/6: VirtualDisplay created OK")
        }

        ruleStates.clear()
        PrefsManager.loadRules(this).filter { it.enabled }.forEach { r ->
            ruleStates[r.id] = RuleState(r)
        }

        thread = HandlerThread("ColorTapSampler").also { it.start() }
        handler = Handler(thread!!.looper)
        running = true
        EventBus.setRunning(true)
        EventBus.log("Screen capture started (${width}x$height)")
        if (android.provider.Settings.canDrawOverlays(this)) {
            startService(Intent(this, StatsOverlayService::class.java))
        }
        scheduleSample()
    }

    private fun scheduleSample() {
        if (!running) return
        val interval = PrefsManager.globalSampleIntervalMs(this)
        handler?.postDelayed({
            sampleOnce()
            scheduleSample()
        }, interval)
    }

    private fun sampleOnce() {
        val reader = imageReader ?: return
        val image = try { reader.acquireLatestImage() } catch (e: Exception) { null } ?: return
        try {
            val plane = image.planes[0]
            val buffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val width = image.width

            for (state in ruleStates.values) {
                val rule = state.rule
                if (rule.detectX < 0 || rule.detectY < 0) continue
                if (rule.detectX >= image.width || rule.detectY >= image.height) continue
                val offset = rule.detectY * rowStride + rule.detectX * pixelStride
                if (offset + 3 >= buffer.capacity()) continue
                val r = buffer.get(offset).toInt() and 0xFF
                val g = buffer.get(offset + 1).toInt() and 0xFF
                val b = buffer.get(offset + 2).toInt() and 0xFF
                val color = (0xFF shl 24) or (r shl 16) or (g shl 8) or b

                val action = state.onColorSampled(color)
                EventBus.log("${rule.name}: ${state.progressText}")
                if (action != null) {
                    EventBus.log(">> TAP x${action.tapCount} at (${action.x},${action.y}) [${rule.name}]")
                    TapAccessibilityService.instance?.performTaps(action.x, action.y, action.tapCount, action.intervalMs)
                        ?: EventBus.log("Accessibility service not enabled - cannot tap!")
                }
            }
            publishStats()
        } catch (t: Throwable) {
            EventBus.log("Sample error: ${t.javaClass.simpleName}: ${t.message}")
        } finally {
            image.close()
        }
    }

    private fun publishStats() {
        if (ruleStates.isEmpty()) {
            EventBus.setStats("No active rules")
            return
        }
        val text = ruleStates.values.joinToString("\n") { s ->
            "${s.rule.name}: ${s.progressText}  •  taps: ${s.totalTaps}"
        }
        EventBus.setStats(text)
    }

    private fun stopCapture() {
        running = false
        EventBus.setRunning(false)
        EventBus.log("Screen capture stopped")
        handler?.removeCallbacksAndMessages(null)
        thread?.quitSafely()
        virtualDisplay?.release()
        imageReader?.close()
        mediaProjection?.stop()
        virtualDisplay = null
        imageReader = null
        mediaProjection = null
        stopService(Intent(this, StatsOverlayService::class.java))
        androidx.core.app.ServiceCompat.stopForeground(this, androidx.core.app.ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        if (running) stopCapture()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null

    companion object {
        const val NOTIF_ID = 4201
        const val ACTION_STOP = "com.colortap.bot.STOP_CAPTURE"
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_DATA = "data"
    }
}
